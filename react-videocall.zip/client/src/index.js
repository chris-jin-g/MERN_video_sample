import React from 'react';
import { render } from 'react-dom';
import App from './js/App';
import './css/app.scss';

render(<App />, document.getElementById('root'));
